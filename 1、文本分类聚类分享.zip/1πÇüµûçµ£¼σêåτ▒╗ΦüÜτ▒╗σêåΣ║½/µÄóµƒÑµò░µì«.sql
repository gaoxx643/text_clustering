select 
	role,	
	rate_num,# 评价星级1-5星
	driver_comment,# 司机评价乘客的内容，多条以逗号分隔
	rate_detail, # 长文评价内容，多条以逗号分隔
	good_tag,# 正向评价，多条以逗号分隔
	bad_tag, # 负向评价，多条以逗号分隔
	private_comment, # 隐私评价内容


from 
	beatles_dwd.dwd_addtag_statistic_d
where 
	CONCAT_WS('-', year, month, day) <= '2018-08-03'
	-- and CONCAT_WS('-', year, month, day) >= '2018-08-01'
	and role = 0
rate_num


select 
	param['order_id'],
	param['passenger_comment'] as passenger_comment,
	param['good_tags'],
	param['bad_tags'],
	param['rate_detail'],
	param['rate_num']
from
	beatles_ods.beatles_addtag_statistic
where 
	CONCAT_WS('-', year, month, day) = '2018-03-03'
	and param['role'] = '1'
	and pparam['rate_detail']<>''
	and param['rate_detail'] is not null
	limit 1000


select 
	param['order_id'] as order_id,
	param['rate_detail'] as rate_detail,
	param['rate_num'] as rate_num,
	param['bad_tags'] as bad_tags,
	param['good_tags'] as good_tags,
	param['private_comment'] as private_comment,
	param['passenger_comment'] as passenger_comment,
	length(param['rate_detail']) as detailLens
from
	beatles_ods.beatles_addtag_statistic
where 
	CONCAT_WS('-', year, month, day) = '2018-03-03'
	and param['role'] = '1'
	and param['rate_detail']<>''
	and param['rate_detail'] is not null
	and detailLens>20
group by 
	param['order_id'],
	param['rate_detail'],
	param['rate_num'],
	param['bad_tags'],
	param['good_tags'],
	param['private_comment'],
	param['passenger_comment']

select 
	param['order_id'] as order_id,
	param['rate_detail'] as rate_detail,
	param['rate_num'] as rate_num
from
	beatles_ods.beatles_addtag_statistic
where 
	CONCAT_WS('-', year, month, day) = '2018-03-03'
	and param['role'] = '1'
	and param['rate_detail']<>''
	and param['rate_detail'] is not null
	and detailLens>20
group by 
	param['order_id'],
	param['rate_detail'],
	param['rate_num'],
	param['bad_tags'],
	param['good_tags'],
	param['private_comment'],
	param['passenger_comment']





	limit 1000


select
	count(1)
from
	beatles_ods.beatles_addtag_statistic
where
	CONCAT_WS('-', year, month, day) = '2018-03-03'
	and param['role'] = '1'
	and param['rate_detail']<>''
	and param['rate_detail'] is not null







select 
	param['bad_tags'],
	count(*) as nums
from
	beatles_ods.beatles_addtag_statistic
where 
	CONCAT_WS('-', year, month, day) = '2018-08-03'
	-- and CONCAT_WS('-', year, month, day) >= '2018-08-01'
	and param['role'] = '1'
	and param['passenger_comment']<>''
	and param['private_comment']<>''
group by param['bad_tags']
order by nums



select 
	param['bad_tags'] as bad_tags,
	param['good_tags'] as good_tags,
	param['private_comment'] as private_comment,
	param['passenger_comment'] as passenger_comment,
	param['driver_comment'] as driver_comment
from
	beatles_ods.beatles_addtag_statistic
where 
	CONCAT_WS('-', year, month, day) < '2018-08-03'
	and CONCAT_WS('-', year, month, day) >= '2018-08-01'
	and param['role'] = '0'
	and param['private_comment']<>''








select
    distinct a.token as token,
    a.user_id as user_id,
    '15' as product_id,
    a.create_time as create_time,
    'E' as tag_type,
    '2019' as year,
    '03' as month,
    '18' as day,
    '22'as hour
    from
    (
    select
    tag,
    param['order_id'] as token,
    param['driver_id'] as user_id,
    param['create_time'] as create_time
    FROM
    beatles_ods.beatles_addtag_statistic
    LATERAL VIEW explode(split(param['passenger_comment'],'\,')) my_table as tag
    WHERE concat_ws('-',year,month,day,hour)='2019-03-18-22'
    )a
    WHERE a.tag IN ('车牌不符','车型不符')
    distribute by(year,month,day,hour)


select 
critic_type,
rate,
case when rate='5' then '好评'
when rate<>'5' then '差评'
end as comment_type,
concat(d_comment,p_comment) as comment,
long_comment
from
(
select order_id 
from beatles_dwd.dwd_order_create_d
where pt='2019-03-17' and cross_city_type=0
)aa
join 
(
select param['order_id'] as order_id,
case when get_json_object(param['private_comment'],'$.23000') is not null then '司机'
else '乘客'
end as critic_type,
param['rate_num'] as rate,
param['driver_comment'] as d_comment,
param['passenger_comment'] as p_comment,
param['rate_detail'] as long_comment
from beatles_ods.beatles_addtag_statistic
where concat_ws('-',year,month,day)='2019-03-17'
)bb
on aa.order_id=bb.order_id
order by critic_type